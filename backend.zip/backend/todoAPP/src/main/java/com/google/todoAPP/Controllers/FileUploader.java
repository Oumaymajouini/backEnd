package com.google.todoAPP.Controllers;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

@RestController
public class FileUploader {
    String imageFolder="C:/myprojects/Angular/src/assets/img";
    @PostMapping("/files/uploadImage")
    public String UploadImage(@RequestParam("file") MultipartFile file){
        System.out.println(file.getOriginalFilename());
        try{
            String fileName=file.getOriginalFilename().replace(" ", "");
            File fileObj = new File(imageFolder+"/"+fileName);
            byte[] fileBytes=file.getBytes();
        // Initialize a pointer
            // in file using OutputStream
            OutputStream  os= new FileOutputStream(fileObj);
  
            // Starts writing the bytes in it
            os.write(fileBytes);
            System.out.println("Successfully"
                               + " byte inserted");
  
            // Close the file
            os.close();
            return "File Uploaded Successfully";
        } catch (Exception e ){
            e.printStackTrace();
        }

        return "";
    }
}
