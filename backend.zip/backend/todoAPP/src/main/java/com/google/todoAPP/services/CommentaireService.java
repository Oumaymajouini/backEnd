package com.google.todoAPP.services;

import com.google.todoAPP.entities.Commentaire;

public interface CommentaireService {
    public Commentaire creatCommentaire(Commentaire commentaire);
    
}
