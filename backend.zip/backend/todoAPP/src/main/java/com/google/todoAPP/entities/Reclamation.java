package com.google.todoAPP.entities;

import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Id;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.validation.constraints.Email;
@Entity
@Table(name = "reclamation")
public class Reclamation {
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Long recId;
    @Email
    private String email;
    private String sujet;
    private String message;
    private String  etat;
    public Reclamation() {
    }
   
   
    public Reclamation(@Email String email, String sujet, String message, String etat) {
        this.email = email;
        this.sujet = sujet;
        this.message = message;
        this.etat = etat;
    }


    public Long getRecId() {
        return recId;
    }
    public void setRecId(Long recId) {
        this.recId = recId;
    }
    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    public String getSujet() {
        return sujet;
    }
    public void setSujet(String sujet) {
        this.sujet = sujet;
    }
    public String getMessage() {
        return message;
    }
    public void setMessage(String message) {
        this.message = message;
    }
    
    public String getEtat() {
        return etat;
    }


    public void setEtat(String etat) {
        this.etat = etat;
    }


    @Override
    public String toString() {
        return "Reclamation [email=" + email + ", etat=" + etat + ", message=" + message + ", recId=" + recId
                + ", sujet=" + sujet + "]";
    }


   
   
    



    
}




