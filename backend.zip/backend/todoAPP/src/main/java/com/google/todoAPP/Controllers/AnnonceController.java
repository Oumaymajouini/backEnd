package com.google.todoAPP.Controllers;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import java.util.Optional;

import javax.servlet.ServletContext;
import java.io.FileOutputStream;
// import java.io.InputStream;
import java.io.OutputStream;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.todoAPP.entities.Annonce;
import com.google.todoAPP.entities.Localisation;
import com.google.todoAPP.entities.User;
import com.google.todoAPP.repositories.AnnonceRepository;
import com.google.todoAPP.repositories.LocalisationRepository;
import com.google.todoAPP.repositories.UserRepository;
import com.google.todoAPP.services.AnnonceService;
import com.google.todoAPP.services.LocalisationService;

// import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
// import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class AnnonceController {

    String imageFolder = "C:/myprojects/backend/todoAPP/src/main/webapp/Images";

    @Autowired
    AnnonceRepository repository;

    @Autowired
    ServletContext context;
    @Autowired
    AnnonceService annonceService;
    @Autowired
    LocalisationService localisation;
    @Autowired
    LocalisationRepository repo;
    @Autowired
    UserRepository repoo;

    // create
    @PostMapping(path = "/annonce/create")

    public String createAnnonce(@RequestBody Annonce annonce) throws Exception {
    
        annonceService.creatAnnonce(annonce);

        return "Annonce ajouté avec succée";
    }

    // ListAnnonces
    @GetMapping(path = "/annonce/list")

    public List<Annonce> listAnnonces() {
        return annonceService.listAnnonce();
    }

    // liste annonces par user
    @GetMapping(path = "/annonce/user")

    public List<Annonce> listAnnonce(@RequestBody User user) {
        return annonceService.listAnn(user);
    }
    // getAnnonce

    @GetMapping(path = "/annonce/{AnnonceId}")
    public Optional<Annonce> getAnnonce(@PathVariable(name = "AnnonceId") Long AnnonceId) {
        return annonceService.findById(AnnonceId);

    }

    // delete
    @DeleteMapping(path = "/annonce/delete/{AnnonceId}")
    public String deleteAnnonce(@PathVariable(name = "AnnonceId") Long AnnonceId) {
        annonceService.deleteAnnonce(AnnonceId);
        return "Annonce supprimé avec succée";
    }

    // uploadfile
    // @PostMapping(path = "/annonces")

    // public long createAnnonce(@RequestParam("file") MultipartFile file,
    // @RequestParam("annonce") String annonce) throws JsonParseException,
    // JsonMappingException, Exception {
    // System.out.println("Ok .............");
    // Annonce ann = new ObjectMapper().readValue(annonce, Annonce.class);
    // boolean isExit = new File(context.getRealPath("/Images/")).exists();
    // if (!isExit) {
    // new File(context.getRealPath("/Images/")).mkdir();
    // System.out.println("mk dir.............");
    // }
    // String filename = file.getOriginalFilename();
    // String newImage = FilenameUtils.getBaseName(filename) + "." +
    // FilenameUtils.getExtension(filename);
    // File serverFile = new
    // File(context.getRealPath("/Images/"+File.separator+newImage));
    // try {
    // System.out.println("Image");
    // FileUtils.writeByteArrayToFile(serverFile, file.getBytes());

    // } catch (Exception e) {
    // e.printStackTrace();
    // }

    // ann.setImage(newImage);
    // return annonceService.save(ann);
    // }
    // upload
    @PostMapping(path = "/annonces")
    public long UploadImage(@RequestParam("file") MultipartFile file,
            @RequestParam("annonce") String annonce) throws JsonParseException, JsonMappingException, Exception {
        Annonce ann = new ObjectMapper().readValue(annonce, Annonce.class);

        String filename = file.getOriginalFilename();
        String newImage = FilenameUtils.getBaseName(filename) + "." + FilenameUtils.getExtension(filename);
  
        try {
            String fileName = file.getOriginalFilename().replace(" ", "");
            File fileObj = new File(imageFolder + "/" + fileName);
            byte[] fileBytes = file.getBytes();

            OutputStream os = new FileOutputStream(fileObj);

            os.write(fileBytes);
            System.out.println("Successfully"
                    + " byte inserted");

            os.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        ann.setImage(newImage);
  
        return annonceService.save(ann);
    }

    // getPhoto
    @GetMapping(path = "/Imgannonces/{AnnonceId}")
    public byte[] getPhoto(@PathVariable("AnnonceId") Long AnnonceId) throws Exception {
        Annonce annonce = annonceService.findById(AnnonceId).get();
        return Files.readAllBytes(
                Paths.get(("C:/myprojects/backend/todoAPP/src/main/webapp/Images") + "/" + annonce.getImage()));

    }

}
