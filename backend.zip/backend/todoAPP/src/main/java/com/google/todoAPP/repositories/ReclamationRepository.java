package com.google.todoAPP.repositories;

import java.util.List;

import com.google.todoAPP.entities.Reclamation;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
@Repository
public interface ReclamationRepository extends JpaRepository<Reclamation,Long> {
    public List<Reclamation> findByEtat(String etat);
}
