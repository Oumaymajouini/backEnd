package com.google.todoAPP.services.impl;

import com.google.todoAPP.entities.Commentaire;
import com.google.todoAPP.repositories.CommentaireRepository;
import com.google.todoAPP.services.CommentaireService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CommentaireServiceImpl  implements CommentaireService  {
    @Autowired
    private CommentaireRepository commentaireRepository;   


    @Override
    public Commentaire creatCommentaire(Commentaire commentaire) {
        return commentaireRepository.save(commentaire);
       
    }

}
