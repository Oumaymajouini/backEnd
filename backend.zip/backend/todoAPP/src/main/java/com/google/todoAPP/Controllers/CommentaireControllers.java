package com.google.todoAPP.Controllers;

import com.google.todoAPP.entities.Commentaire;
import com.google.todoAPP.services.CommentaireService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CommentaireControllers {
    @Autowired
CommentaireService commentaireService;


    @PostMapping(path = "/commentaire/create")
    @CrossOrigin(origins = "http://localhost:4200")
    public String createAnnonce(@RequestBody Commentaire commentaire)throws Exception{
        commentaireService.creatCommentaire(commentaire);
        return "Commentaire ajouté avec succée";
    }
}
