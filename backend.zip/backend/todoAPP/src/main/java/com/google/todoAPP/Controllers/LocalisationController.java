package com.google.todoAPP.Controllers;

import java.util.List;

import com.google.todoAPP.entities.Localisation;
import com.google.todoAPP.repositories.LocalisationRepository;
import com.google.todoAPP.services.LocalisationService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class LocalisationController {
    @Autowired
    LocalisationService locService;
    @Autowired
    LocalisationRepository repository;
    //Post
    @PostMapping(path = "/localisation/create")
  
    public String createLocalisation(@RequestBody Localisation localisation)throws Exception{
        locService.creatLocalisation(localisation);
     
        return "localisation ajouté avec succée";
    }

    @GetMapping(path = "/Localisations")
    
    public List<Localisation> listLocalisations(){
        return locService.listLocalisation();
    }
      // delete
  @DeleteMapping(path = "/localisation/delete/{localisationId}")
  public String deleteLocalisation(@PathVariable(name = "localisationId") Long localisationId) {
    locService.deleteLocalisation(localisationId);
      return "localisation supprimé avec succée";
  }
}
