package com.google.todoAPP.services;

import java.util.Optional;

import com.google.todoAPP.entities.Offre;

public interface OffreService {
    public Offre creatOffre(Offre offre) ;
    public long save(Offre offre);
    public Optional<Offre> findById(Long offreId) ;
    
}
