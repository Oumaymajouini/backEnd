package com.google.todoAPP.repositories;


import com.google.todoAPP.entities.Commentaire;

import org.springframework.data.jpa.repository.JpaRepository;

public interface CommentaireRepository  extends JpaRepository<Commentaire,Long> {

  
    
}
