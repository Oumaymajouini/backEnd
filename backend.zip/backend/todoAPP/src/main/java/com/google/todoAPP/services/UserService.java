package com.google.todoAPP.services;

import java.util.List;
import java.util.Optional;

import com.google.todoAPP.entities.User;




public interface UserService {
    public User creatUser(User user);
    public User fetchUserByEmail(String email);
    public User fetchUserByusername(String username);
    public User fetchUserByEmailAndPassword(String email,String password);
    public void deleteUser(Long userId);
    public User getUser(Long userId);
    public List<User> listUser();
    public List<User> findByEtat(String etat);
    public User updateUser(User user);
    public long save(User user);
    public Optional<User> findById(Long userId);
    public void  Update (long userId,User User);

  
   
    
}
