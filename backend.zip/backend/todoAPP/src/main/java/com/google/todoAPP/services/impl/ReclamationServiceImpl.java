package com.google.todoAPP.services.impl;

import java.util.List;
import java.util.Optional;

import com.google.todoAPP.entities.Reclamation;
import com.google.todoAPP.repositories.ReclamationRepository;
import com.google.todoAPP.services.ReclamationService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ReclamationServiceImpl  implements ReclamationService {
    @Autowired
    private ReclamationRepository reclamationRepository;


    @Override
    public Reclamation creatReclamation(Reclamation reclamation) {
        return reclamationRepository.save(reclamation);
    }


    @Override
    public void deleteReclamation(Long recId) {
        Reclamation reclamation = reclamationRepository.findById(recId).get();
        reclamationRepository.delete(reclamation);
    }
    @Override
    public List<Reclamation> listReclamation() {        
        return reclamationRepository.findAll();
    }


    @Override
    public List<Reclamation> findByEtat(String etat) {
       
        return reclamationRepository.findByEtat(etat);
    }
    @Override
    public Reclamation getReclamation(Long recId) {
        Reclamation reclamation = reclamationRepository.findById(recId).get();
      return reclamation;
    }
    @Override
    public Reclamation updateReclamation(Reclamation reclamation) {
      Optional <Reclamation>  utoptional=reclamationRepository.findById(reclamation.getRecId());
      if (utoptional.isEmpty()){
          return null;

      } else {
          return reclamationRepository.save(reclamation);
      }

       
    }
}
