package com.google.todoAPP.services;

import java.util.List;

import com.google.todoAPP.entities.Categorie;

public interface CategorieService {
    public Categorie creatCategorie(Categorie categorie);
    public List<Categorie> listCategorie();
    public void deleteCategorie(Long categorieId);
    
}
