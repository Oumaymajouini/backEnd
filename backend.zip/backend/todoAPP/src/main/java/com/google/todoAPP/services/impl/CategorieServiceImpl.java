package com.google.todoAPP.services.impl;

import java.util.List;

import com.google.todoAPP.entities.Categorie;
import com.google.todoAPP.repositories.CategorieRepository;
import com.google.todoAPP.services.CategorieService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CategorieServiceImpl implements CategorieService  {
    @Autowired
    private CategorieRepository categorieRepository;
    
    @Override
    public Categorie creatCategorie(Categorie categorie) {
        return categorieRepository.save(categorie);
    }
    @Override
    public List<Categorie> listCategorie() {        
        return categorieRepository.findAll();
    }

    @Override
    public void deleteCategorie(Long categorieId) {
        Categorie categorie = categorieRepository.findById(categorieId).get();
        categorieRepository.delete(categorie);
    }
}
