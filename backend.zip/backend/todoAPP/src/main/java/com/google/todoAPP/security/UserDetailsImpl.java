// package com.google.todoAPP.security;

// import java.util.ArrayList;
// import java.util.Collection;
// import java.util.List;
// import com.fasterxml.jackson.annotation.JsonIgnore;
// import com.google.todoAPP.entities.User;
// import org.slf4j.Logger;
// import org.slf4j.LoggerFactory;
// import org.springframework.security.core.GrantedAuthority;
// import org.springframework.security.core.authority.SimpleGrantedAuthority;
// import org.springframework.security.core.userdetails.UserDetails;

// public class UserDetailsImpl implements UserDetails {
//     private Long userId;
//     private String username;
//     private String email;
//     @JsonIgnore
//     private String password;

// private Collection<? extends GrantedAuthority> authorities;
// private static final Logger logger= LoggerFactory.getLogger(UserDetailsImpl.class.getName());

// public static UserDetailsImpl build (User user){
//     logger.info("roles:"+user.getRole().toString());
//     List<GrantedAuthority> authorities =new ArrayList<>();
//     GrantedAuthority grantedAuthority=new SimpleGrantedAuthority(user.getRole());
//     authorities.add(grantedAuthority);

//     return new  UserDetailsImpl(user.getUserId(),user.getUsername(),
//     user.getEmail(),user.getPassword(),authorities);
// }
  

  
//     public UserDetailsImpl(Long userId, String username, String email, String password,
//         Collection<? extends GrantedAuthority> authorities) {
//     this.userId = userId;
//     this.username = username;
//     this.email = email;
//     this.password = password;
//     this.authorities = authorities;
// }



//     public Long getUserId() {
//         return userId;
//     }
//     public void setUserId(Long userId) {
//         this.userId = userId;
//     }
  
  
//     public void setUsername(String username) {
//         this.username = username;
//     }
//     public String getEmail() {
//         return email;
//     }
//     public void setEmail(String email) {
//         this.email = email;
//     }
//     public void setPassword(String password) {
//         this.password = password;
//     }
//     @Override
//     public String getPassword() {
      
//         return null;
//     }
//     public void setAuthorities(Collection<? extends GrantedAuthority> authorities) {
//         this.authorities = authorities;
//     }
   

//     @Override
//     public Collection<? extends GrantedAuthority> getAuthorities() {
       
//         return authorities;
//     }
//     @Override
//     public boolean isAccountNonExpired() {
   
//         return false;
//     }
//     @Override
//     public boolean isAccountNonLocked() {
      
//         return false;
//     }
//     @Override
//     public boolean isCredentialsNonExpired() {
       
//         return false;
//     }
//     @Override
//     public boolean isEnabled() {
    
//         return false;
//     }
//     @Override
//     public String getUsername() {
       
//         return username;
//     }

  

   
    
// }
