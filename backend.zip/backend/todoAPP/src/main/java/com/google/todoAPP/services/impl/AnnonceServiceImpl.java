package com.google.todoAPP.services.impl;

import java.util.List;
import java.util.Optional;
import com.google.todoAPP.entities.Annonce;
import com.google.todoAPP.entities.User;
import com.google.todoAPP.repositories.AnnonceRepository;
import com.google.todoAPP.services.AnnonceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
@Service
public class AnnonceServiceImpl implements AnnonceService {
    @Autowired
    private AnnonceRepository annonceRepository;


    @Override
    public Annonce creatAnnonce(Annonce annonce) {
        return annonceRepository.save(annonce);
    }
   
    @Override
    public List<Annonce> listAnnonce() {        
        return annonceRepository.findAll();
    }
    
    @Override
    public List<Annonce> listAnn(User user) {        
        return  user.getAnnonces();
    }
    @Override
    public void deleteAnnonce(Long AnnonceId) {
        Annonce annonce = annonceRepository.findById(AnnonceId).get();
        annonceRepository.delete(annonce);
    }

    @Override
    public long save(Annonce annonce) {
       System.out.println("save annonce");
       Annonce an=new Annonce();
       an.setLocalisation(annonce.getLocalisation());
       an.setCategorie(annonce.getCategorie());
       an.setPrix(annonce.getPrix());
       an.setDate(annonce.getDate());
       an.setImage(annonce.getImage());
       an.setDescription(annonce.getDescription());

        return annonceRepository.save(an).getAnnonceId();
    }

    public Optional<Annonce> findById(Long AnnonceId) {
        return annonceRepository.findById(AnnonceId);
  }
  

}
