package com.google.todoAPP.Controllers;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HomeController {
  
  
    @GetMapping(path="/home")
   public String Home(@RequestParam(name="firstname")String firstname,
   @RequestParam(name="lastname")String lastname){
  

       return "Hello word "+firstname+"  "+lastname;
   } 

   @GetMapping(path="/home2/{firstname}")
   public String Home2(@PathVariable(value ="firstname")String firstname,
   @RequestParam(name="lastname")String lastname){
  

       return "Hello word "+firstname+"  "+lastname;
   } 

}
