package com.google.todoAPP.services.impl;

import java.util.Optional;

import com.google.todoAPP.entities.Offre;
import com.google.todoAPP.repositories.OffreRepository;
import com.google.todoAPP.services.OffreService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class OffreServiceImpl implements OffreService {
    @Autowired
    private OffreRepository offreRepository;

    @Override
    public Offre creatOffre(Offre offre) {
        return offreRepository.save(offre);
    }


    @Override
    public long save(Offre offre) {
       System.out.println("save offre");
       Offre of=new Offre();
       of.setProfile(offre.getProfile());
       of.setExperience(offre.getExperience());
       of.setDuree(offre.getDuree());
       of.setPrix(offre.getPrix());
       of.setImage(offre.getImage());
       of.setTelephone(offre.getTelephone());
        return offreRepository.save(of).getOffreId();
    }
    public Optional<Offre> findById(Long offreId) {
        return offreRepository.findById(offreId);
  }
}
