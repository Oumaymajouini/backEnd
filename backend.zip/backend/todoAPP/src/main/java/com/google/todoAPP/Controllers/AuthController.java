// package com.google.todoAPP.Controllers;

// import org.springframework.web.bind.annotation.RestController;
// import com.google.todoAPP.playload.LoginRequest;
// import com.google.todoAPP.playload.LoginResponse;
// import com.google.todoAPP.security.JWTUtils;
// import com.google.todoAPP.security.UserDetailsImpl;

// import java.util.List;
// import java.util.stream.Collectors;

// import org.springframework.beans.factory.annotation.Autowired;
// import org.springframework.security.authentication.AuthenticationManager;
// import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
// import org.springframework.security.core.Authentication;
// import org.springframework.security.core.context.SecurityContextHolder;
// import org.springframework.web.bind.annotation.RequestBody;

// @RestController
// public class AuthController {
//     @Autowired
//     AuthenticationManager authenticationManager;
//     @Autowired
//     JWTUtils jwtUtils;

//     public LoginResponse signin(@RequestBody LoginRequest loginRequest) {
//         Authentication authentication = authenticationManager
//                 .authenticate(new UsernamePasswordAuthenticationToken(loginRequest.getUsername(),
//                         loginRequest.getPassword()));
//         SecurityContextHolder.getContext().setAuthentication(authentication);
//         String jwt = jwtUtils.generateJwtToken(authentication);
//         UserDetailsImpl userDetailsImpl = (UserDetailsImpl) authentication.getPrincipal();
//         List<String> role = userDetailsImpl
//                 .getAuthorities().stream().map(item -> item.getAuthority())
//                 .collect(Collectors.toList());
//         return new LoginResponse(userDetailsImpl.getUserId(), userDetailsImpl.getUsername(),
//                 userDetailsImpl.getEmail(), role, jwt);
//     }
// }
