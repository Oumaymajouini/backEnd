package com.google.todoAPP.entities;




import javax.persistence.Entity;

import javax.persistence.Id;

import javax.persistence.Table;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
@Entity
@Table(name = "categories")
public class Categorie {
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Long categorieId;
    private String code;
    private String libelle;
    // @OneToMany(mappedBy="categorie",cascade = { CascadeType.PERSIST, CascadeType.MERGE }, fetch = FetchType.EAGER)
    // private List<Annonce> annonces;

    public Categorie() {
    }
   
 
    public Categorie(String code, String libelle) {
        this.code = code;
        this.libelle = libelle;
     
    }


    public String getCode() {
        return code;
    }
    public void setCode(String code) {
        this.code = code;
    }
    public Long getCategorieId() {
        return categorieId;
    }
    public void setCategorieId(Long categorieId) {
        this.categorieId = categorieId;
    }

    public String getLibelle() {
        return libelle;
    }
    public void setLibelle(String libelle) {
        this.libelle = libelle;
    }

 

   

 





   
  
  

    
}
