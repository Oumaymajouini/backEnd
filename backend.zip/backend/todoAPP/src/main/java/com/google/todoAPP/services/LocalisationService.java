package com.google.todoAPP.services;

import java.util.List;

import com.google.todoAPP.entities.Localisation;

public interface LocalisationService {
    public Localisation creatLocalisation(Localisation localisation);
    public List<Localisation> listLocalisation();
    public void deleteLocalisation(Long localisationId);
}
