package com.google.todoAPP.services.impl;

import java.util.List;

import com.google.todoAPP.entities.Localisation;
import com.google.todoAPP.repositories.LocalisationRepository;
import com.google.todoAPP.services.LocalisationService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class LocalisationServiceImpl  implements LocalisationService {
    @Autowired
    private LocalisationRepository Repository;
    
    @Override
    public Localisation creatLocalisation(Localisation localisation) {
        return Repository.save(localisation);
    }
    @Override
    public List<Localisation> listLocalisation() {        
        return Repository.findAll();
    }

    @Override
    public void deleteLocalisation(Long localisationId) {
        Localisation localisation = Repository.findById(localisationId).get();
        Repository.delete(localisation);
    }
}
