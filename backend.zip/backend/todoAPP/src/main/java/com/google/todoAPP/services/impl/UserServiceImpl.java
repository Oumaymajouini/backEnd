package com.google.todoAPP.services.impl;


import java.util.List;
import java.util.Optional;


import com.google.todoAPP.entities.User;

import com.google.todoAPP.repositories.UserRepository;
import com.google.todoAPP.services.UserService;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;


@Service
public class UserServiceImpl implements UserService {
    @Autowired
    private UserRepository userRepository;
   
    @Override
    public User creatUser(User user) {
        return userRepository.save(user);
    }

    @Override
    public User fetchUserByEmail(String email)
   {
    return userRepository.findByEmail(email);
   }
   @Override
   public User fetchUserByusername(String username)
  {
   return userRepository.findByUsername(username);
  }
  
 
   @Override
   public User fetchUserByEmailAndPassword(String email,String password)
   {
       return userRepository.findByEmailAndPassword(email, password);
   }


   

//     User user = userRepository.findById(userId)
//     // .findById(userId)
//         .orElseThrow(() -> new ResourceNotFoundException("User not found for this id :: " + userId));

// user.setNom(userDetails.getNom());
// user.setPrenom(userDetails.getPrenom());
// user.setEmail(userDetails.getEmail());
// user.setDateNaissance(userDetails.getDateNaissance());
// user.setTelephone(userDetails.getTelephone());
// user.setAdresse(userDetails.getAdresse());
// user.setPassword(userDetails.getPassword());


// final User updatedUser = userRepository.save(user);
// return ResponseEntity.ok(updatedUser);
     @Override
     public void deleteUser(Long userId) {
         User user = userRepository.findById(userId).get();
         userRepository.delete(user);
     }

  

    // @Override
    //   public User updateUser(Long userId) {
    //       User user = userRepository.findById(userId).get();
    //       user.setNom(user.getNom());
    //       user.setPrenom(user.getPrenom());
    //      user.setEmail(user.getEmail());
    //      user.setDateNaissance(user.getDateNaissance());
    //       user.setTelephone(user.getTelephone());
    //       user.setAdresse(user.getAdresse());
    //      user.setPassword(user.getPassword());
      
    //      return userRepository.save(user);
    //   }
    @Override
    public User getUser(Long userId) {
        User user = userRepository.findById(userId).get();
      return user;
    }

 
    @Override
    public List<User> listUser() { 
    
        return userRepository.findAll();
    }
  

   
    @Override
    public List<User> findByEtat(String etat) {
       
        return userRepository.findByEtat(etat);
    }

    @Override
    public User updateUser(User user) {
      Optional <User>  utoptional=userRepository.findById(user.getUserId());
      if (utoptional.isEmpty()){
          return null;

      } else {
          return userRepository.save(user);
      }

       
    }

  
    @Override
    public long save(User user) {
       System.out.println("save user");
       User an=new User();
       an.setUsername(user.getUsername());
       an.setEmail(user.getEmail());
       an.setDateNaissance(user.getDateNaissance());
       an.setTelephone(user.getTelephone());
       an.setAdresse(user.getAdresse());
       an.setPassword(user.getPassword());
       an.setRole(user.getRole());
       an.setEtat(user.getEtat());
       an.setProfile(user.getProfile());
       an.setPhoto(user.getPhoto());

        return userRepository.save(an).getUserId();
    }
  
  
 

    public Optional<User> findById(Long userId) {
        return userRepository.findById(userId);
  }

  public void  Update (long userId,User User)
  {Optional<User>userr=userRepository.findById(userId);
    if (userr.isPresent()){
        User user =userr.get();
        user.setUsername(User.getUsername());
        user.setEmail(User.getEmail());
        user.setDateNaissance(User.getDateNaissance());
        user.setTelephone(User.getTelephone());
        user.setAdresse(User.getAdresse());
        user.setPassword(User.getPassword());
        user.setPhoto(User.getPhoto());
        userRepository.save(user);
    }

  }
}
