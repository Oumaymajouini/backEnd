package com.google.todoAPP.Controllers;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import javax.servlet.ServletContext;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import com.google.todoAPP.entities.User;
import com.google.todoAPP.repositories.UserRepository;

import com.google.todoAPP.services.UserService;
import com.google.todoAPP.services.impl.ReclamationServiceImpl;
import com.fasterxml.jackson.core.JsonParseException;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

@RestController

public class UserController {

    String imagedossier = "C:/myprojects/backend/todoAPP/src/main/webapp/ImagesUsers";
    @Autowired
    ReclamationServiceImpl reclamationService;
    @Autowired
    UserService userService;

    @Autowired
    UserRepository userRepository;
    @Autowired
    ServletContext context;

    // createUser
    @PostMapping(path = "/user/create")
    @CrossOrigin(origins = "http://localhost:4200")
    public User createUser(@RequestBody User user) throws Exception {
        String tempEmailId = user.getEmail();
        if (tempEmailId != null && !"".equals(tempEmailId)) {
            User userObj = userService.fetchUserByEmail(tempEmailId);
            if (userObj != null) {
                throw new Exception("user with" + tempEmailId + "is ready exist");
            }
        }

        userService.creatUser(user);

        return user;
        // return "User ajouté avec succée";
    }

    // deleteuser
    @CrossOrigin(origins = "http://localhost:4200")
    @DeleteMapping(path = "/user/delete/{userID}")
    public String deleteUser(@PathVariable(name = "userID") Long userID) {
        userService.deleteUser(userID);
        return "User supprimé avec succée";
    }

    // getListUser
    @GetMapping(path = "/user/list")
    @CrossOrigin(origins = "http://localhost:4200")
    public List<User> listUser() {
        return userService.listUser();

    }

    // getUser
    @CrossOrigin(origins = "http://localhost:4200")
    @GetMapping(path = "/user/{userID}")
    public User getUser(@PathVariable(name = "userID") Long userID) {
        return userService.getUser(userID);

    }

    // login
    @PostMapping(path = "/login")
    @CrossOrigin(origins = "http://localhost:4200")
    public User loginUser(@RequestBody User user) throws Exception {
        String tempEmailId = user.getEmail();
        String temppass = user.getPassword();

        User userObj = null;

        if (tempEmailId != null && temppass != null) {
            userObj = userService.fetchUserByEmailAndPassword(tempEmailId, temppass);
        }
        if (userObj == null) {
            throw new Exception("bad credentials");
        }
        // ||userObj.getEtat().equals("bloqué")
        // else if ( userObj.getEtat().equals("bloqué") )
        // {
        // return "vous etes bloqué par l'admin";
        // }
        return userObj;

    }

    // getUsersBloqués
    @GetMapping(path = "/getuserbyetat/{etat}")
    @CrossOrigin(origins = "http://localhost:4200")
    public ResponseEntity<List<User>> findUserByEtat(@PathVariable String etat) {
        List<User> utilisateurs = userService.findByEtat(etat);
        if (utilisateurs.isEmpty()) {
            return new ResponseEntity<List<User>>(HttpStatus.NO_CONTENT);
        } else {
            return new ResponseEntity<List<User>>(utilisateurs, HttpStatus.OK);
        }
    }

    // getUsersnonBloqués
    @GetMapping(path = "/getusers/{etat}")
    @CrossOrigin(origins = "http://localhost:4200")
    public ResponseEntity<List<User>> findUsers(@PathVariable String etat) {
        List<User> utilisateurs = userService.findByEtat(etat);
        if (utilisateurs.isEmpty()) {
            return new ResponseEntity<List<User>>(HttpStatus.NO_CONTENT);
        } else {
            return new ResponseEntity<List<User>>(utilisateurs, HttpStatus.OK);
        }
    }

    // updateUser
    @CrossOrigin(origins = "http://localhost:4200")
    @PutMapping(path = "/update")
    public User updateUser(@RequestBody User user) {

        return userService.updateUser(user);
    }

    // debloquerUser
    @CrossOrigin(origins = "http://localhost:4200")
    @PutMapping(path = "/updatechamps/{userId}")
    public User updatechamps(@PathVariable(name = "userId") Long userId) {
        User user = userService.getUser(userId);

        user.setEtat("non bloqué");
        return userService.updateUser(user);

    }

    // bloquerUser
    @CrossOrigin(origins = "http://localhost:4200")
    @PutMapping(path = "/bloquer/{userId}")
    public User bloqueruser(@PathVariable(name = "userId") Long userId) {
        User user = userService.getUser(userId);

        user.setEtat("bloqué");
        return userService.updateUser(user);

    }

    // createUser
    @PostMapping(path = "/users")
    @CrossOrigin(origins = "http://localhost:4200")
    public long UploadImage(@RequestParam("file") MultipartFile file,
            @RequestParam("user") String user) throws JsonParseException, JsonMappingException, Exception {
        User ann = new ObjectMapper().readValue(user, User.class);

        String filename = file.getOriginalFilename();
        String newImage = FilenameUtils.getBaseName(filename) + "." + FilenameUtils.getExtension(filename);

        try {
            String fileName = file.getOriginalFilename().replace(" ", "");
            File fileObj = new File(imagedossier + "/" + fileName);
            byte[] fileBytes = file.getBytes();

            OutputStream os = new FileOutputStream(fileObj);

            os.write(fileBytes);
            System.out.println("Successfully"
                    + " byte inserted");

            os.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        ann.setPhoto(newImage);
        return userService.save(ann);
    }

    // getPhoto
    @GetMapping(path = "/Imgusers/{userId}")
    public byte[] getPhoto(@PathVariable("userId") Long userId) throws Exception {
        User user = userService.findById(userId).get();
        return Files.readAllBytes(
                Paths.get(("C:/myprojects/backend/todoAPP/src/main/webapp/ImagesUsers") + "/" + user.getPhoto()));

    }

    @PostMapping(path = "/usersupdate")
    @CrossOrigin(origins = "http://localhost:4200")
    public long createUser(@RequestParam("file") MultipartFile file,
            @RequestParam("user") String user) throws JsonParseException, JsonMappingException, Exception {
        User userr = new ObjectMapper().readValue(user, User.class);
        addUserImage(file);
        String filename = file.getOriginalFilename();
        String newFileName = FilenameUtils.getBaseName(filename) + "." + FilenameUtils.getExtension(filename);
        userr.setPhoto(newFileName);
        return userService.save(userr);

    }

    private void addUserImage(MultipartFile file) {

        String filename = file.getOriginalFilename();
        String newFileName = FilenameUtils.getBaseName(filename) + "." + FilenameUtils.getExtension(filename);

        File fileObj = new File(imagedossier + "/" + filename);
        try {
            FileUtils.writeByteArrayToFile(fileObj, file.getBytes());
        } catch (Exception e) {
            System.out.println("failed to aad image user !! ");
        }

    }

    @PutMapping(path = "/users/{userID}")
    @CrossOrigin(origins = "http://localhost:4200")
    public void update(@PathVariable long userID, @RequestParam("file") MultipartFile file,
            @RequestParam("user") String user) throws JsonParseException, JsonMappingException, Exception {

        User userr = new ObjectMapper().readValue(user, User.class);
        deleteUserImage(userr);
        String filename = file.getOriginalFilename();
        String newFileName = FilenameUtils.getBaseName(filename) + "." + FilenameUtils.getExtension(filename);
        userr.setPhoto(newFileName);
        userService.Update(userID, userr);
        addUserImage(file);
    }

    private void deleteUserImage(User user) {
        System.out.println("delete user image");
        try {
            File file = new File(imagedossier + "/" + user.getPhoto());

            System.out.println(user.getPhoto());
            if (file.delete()) {
                System.out.println(file.getName() + "is deleted");

            } else {
                System.out.println("delete operation is failed ");

            }
        } catch (Exception e) {

            System.out.println("Failed to delete image ");
        }
    }

}
