package com.google.todoAPP.services;

import java.util.List;
import java.util.Optional;


import com.google.todoAPP.entities.Annonce;
import com.google.todoAPP.entities.User;



public interface AnnonceService {
    public Annonce creatAnnonce(Annonce annonce);
    public List<Annonce> listAnnonce();
    public List<Annonce> listAnn(User user);
    public void deleteAnnonce(Long AnnonceId) ;
    public long save(Annonce annonce);
    public Optional<Annonce> findById(Long AnnonceId);
   
}
