// package com.google.todoAPP.security;

// import java.util.Date;

// import org.slf4j.Logger;
// import org.slf4j.LoggerFactory;
// import org.springframework.security.core.Authentication;
// import org.springframework.stereotype.Component;

// import io.jsonwebtoken.Jwts;
// import io.jsonwebtoken.MalformedJwtException;
// import io.jsonwebtoken.SignatureAlgorithm;
// import io.jsonwebtoken.SignatureException;
// @Component
// public class JWTUtils {
// private String secret="hgfdsdfghjhgfd@?%£MM/";
// private static final Logger logger = LoggerFactory
// .getLogger(JWTUtils.class.getName());



//     public String generateJwtToken
//     (Authentication authentication ){
//         UserDetailsImpl userPrincipal = 
//         (UserDetailsImpl)  authentication.getPrincipal();
//         return Jwts.builder().setSubject(userPrincipal
//         .getUsername()).setIssuedAt(new Date())
//         .setExpiration(new Date(new Date().
//         getTime()  +  86400000   ))
//         .signWith(SignatureAlgorithm.HS512, 
//         secret)
//         .compact();
//     }
//    public String GetUserNameFromJWtToken(String token) {
//        return Jwts.parser().setSigningKey(secret).parseClaimsJws(token)
//        .getBody().getSubject();
//    }
//    public boolean validateJwtToken(String authToken)
//    {
//        try{
// Jwts.parser().setSigningKey(secret)
// .parseClaimsJws(authToken);
// return true ;
//        } catch(SignatureException e ){
   
//        logger.error("invalid JWT Signature : ",e.getMessage());
//        }catch(MalformedJwtException e){
// logger.error("Invalid JWT token: {}",e.getMessage());
//        } catch(Exception  e ){
//            logger.error("Exception whil validating token : {}",
//             e.getMessage()); 

//        }

       
//        return false ;
//    }
// }
