package com.google.todoAPP.services;

import java.util.List;

import com.google.todoAPP.entities.Reclamation;

public interface ReclamationService {
    public Reclamation creatReclamation(Reclamation reclamation);
    public void deleteReclamation(Long recId) ;
    public List<Reclamation> listReclamation();
    public List<Reclamation> findByEtat(String etat);
    public Reclamation getReclamation(Long recId);
    public Reclamation updateReclamation(Reclamation reclamation);
}
