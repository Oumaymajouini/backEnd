package com.google.todoAPP.entities;

import java.util.List;


import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;


@Entity
@Table(name = "localisation")
public class Localisation {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long localisationId;
    private String libelle;
    @JsonBackReference
	@OneToMany(mappedBy = "localisation",fetch = FetchType.EAGER)
    private List<Annonce> annonces; 
   
    
    public Localisation() {
    }


    public Long getLocalisationId() {
        return localisationId;
    }


    public void setLocalisationId(Long localisationId) {
        this.localisationId = localisationId;
    }


    public String getLibelle() {
        return libelle;
    }


    public void setLibelle(String libelle) {
        this.libelle = libelle;
    }


    public List<Annonce> getAnnonces() {
        return annonces;
    }


    public void setAnnonces(List<Annonce> annonces) {
        this.annonces = annonces;
    }


    @Override
    public String toString() {
        return "Localisation [annonces=" + annonces + ", libelle=" + libelle + ", localisationId=" + localisationId
                + "]";
    }

   

}
