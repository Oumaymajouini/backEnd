package com.google.todoAPP.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;


@Entity

public class Commentaire {
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Long idCommentaire;
    private String Description ;
    public Commentaire() {
    }

    public Commentaire(String description) {
        Description = description;
    }

    public Long getIdCommentaire() {
        return idCommentaire;
    }
    public void setIdCommentaire(Long idCommentaire) {
        this.idCommentaire = idCommentaire;
    }
    public String getDescription() {
        return Description;
    }
    public void setDescription(String description) {
        Description = description;
    }
    @Override
    public String toString() {
        return "Commentaire [Description=" + Description + ", idCommentaire=" + idCommentaire + "]";
    }
    
    
}
