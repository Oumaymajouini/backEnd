// package com.google.todoAPP.services;

// import org.springframework.web.multipart.MultipartFile;
// import java.util.stream.Stream;
// import java.io.IOException;
// import com.google.todoAPP.entities.FileDB;
// public interface FileService {
//     public FileDB store(MultipartFile file) throws IOException  ;
//     public FileDB getFile(String id) ;
//     public Stream<FileDB> getAllFiles();   
// }
