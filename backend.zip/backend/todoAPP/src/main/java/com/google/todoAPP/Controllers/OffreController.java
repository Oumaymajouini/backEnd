package com.google.todoAPP.Controllers;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
// import java.nio.file.Files;
// import java.nio.file.Paths;

import javax.servlet.ServletContext;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.todoAPP.entities.Offre;
import com.google.todoAPP.repositories.OffreRepository;
import com.google.todoAPP.services.OffreService;
import com.fasterxml.jackson.core.JsonParseException;
import org.apache.commons.io.FilenameUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
// import org.springframework.web.bind.annotation.GetMapping;
// import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import com.fasterxml.jackson.databind.JsonMappingException;

@CrossOrigin(origins = "http://localhost:4200") 
@RestController
public class OffreController {
    String imagedossier="C:/myprojects/backend/todoAPP/src/main/webapp/ImagesUsers";
   
    @Autowired
    OffreRepository repository;

    @Autowired
    ServletContext context;
    @Autowired
    OffreService offreService;



       // create
       @PostMapping(path = "/offre/create")

       public String createOffre(@RequestBody Offre offre) throws Exception {
   
           offreService.creatOffre(offre);
   
           return "offre ajouté avec succée";
       }
        //upload
    @PostMapping(path = "/offres")
    public long UploadImage(@RequestParam("file") MultipartFile file,
    @RequestParam("offre") String offre) throws JsonParseException, JsonMappingException, Exception {
        Offre of = new ObjectMapper().readValue(offre, Offre.class);
  
        String filename = file.getOriginalFilename();
        String newImage = FilenameUtils.getBaseName(filename) + "." + FilenameUtils.getExtension(filename);

        try{
            String fileName=file.getOriginalFilename().replace(" ", "");
            File fileObj = new File(imagedossier+"/"+fileName);
            byte[] fileBytes=file.getBytes();
       
            OutputStream  os= new FileOutputStream(fileObj);
  
            
            os.write(fileBytes);
            System.out.println("Successfully"
                               + " byte inserted");
  
           
            os.close();
           
        } catch (Exception e ){
            e.printStackTrace();
        }

        of.setImage(newImage);
    
     return offreService.save(of);
    }

    // // getPhoto
    // @GetMapping(path ="/Imgoffres/{offreId}")
    // public byte[] getPhoto(@PathVariable("offreId") Long offreId) throws Exception {
    //     Offre offre = offreService.findById(offreId).get();
    //      return Files.readAllBytes(Paths.get(("C:/myprojects/backend/todoAPP/src/main/webapp/ImagesUsers")+"/"+offre.getImage()));
       
   
    // }
}
