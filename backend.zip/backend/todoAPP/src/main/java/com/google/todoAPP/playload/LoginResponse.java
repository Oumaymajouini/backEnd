// package com.google.todoAPP.playload;



// public class LoginResponse {
//     private Long userId ;
//     private String username;
//     private String email;
//     private String  role ;
//     private String jwt ;
 

    
  

//     public LoginResponse(Long userId, String username, String email, String role, String jwt) {
//         this.userId = userId;
//         this.username = username;
//         this.email = email;
//         this.role = role;
//         this.jwt = jwt;
//     }


//     public String getJwt() {
//         return jwt;
//     }


//     public void setJwt(String jwt) {
//         this.jwt = jwt;
//     }


//     public Long getUserId() {
//         return userId;
//     }
//     public void setUserId(Long userId) {
//         this.userId = userId;
//     }
//     public String getUsername() {
//         return username;
//     }
//     public void setUsername(String username) {
//         this.username = username;
//     }
//     public String getEmail() {
//         return email;
//     }
//     public void setEmail(String email) {
//         this.email = email;
//     }


//     public String getRole() {
//         return role;
//     }


//     public void setRole(String role) {
//         this.role = role;
//     }


    
    
// }
